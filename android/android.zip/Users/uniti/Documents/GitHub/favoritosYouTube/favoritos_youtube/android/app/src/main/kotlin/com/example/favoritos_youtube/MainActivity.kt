package com.example.favoritos_youtube

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
